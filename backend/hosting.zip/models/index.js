// server/models/index.js
const User = require('./UserModel');
const File = require('./FileModel');

module.exports = {
    User,
    File,
};
